# rampart cad files

This is still in it's infancy.

I start by exporting the PCB view from Fritzing. Then reduce the artwork to 'aperatures'. Then I add text.

Thereafter I import these into jscut.org which just happens to produce the most consistant gcode. I prodce a two part file as a rule.

The first part is all openings and text. Relatively low (50) laser power and fast movement (300?). The second part is only the openings with relatively high power (780 on a 15 watt laser) with movement at or about 280.

Pictures coming soon.
